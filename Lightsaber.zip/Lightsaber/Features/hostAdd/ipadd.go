package hostAdd

import (
	"Lightsaber/Features/Deduplication"
	"Lightsaber/Features/simplifyurl"
	"Lightsaber/src"
	"net"
	"time"
)

var count = 0

func ip(hostadd string) {

	addr, err := net.ResolveIPAddr("ip", simplifyurl.SimplifyUrl(hostadd))
	if err != nil {
		return
	}
	src.Addr.Lock()
	src.UrlAdd[hostadd] = addr.IP.String()
	count -= 1
	src.Addr.Unlock()
}

func GoAddHost(url []string) {

	start := time.Now()
	defer src.UrlAddLock.Done()
	url = Deduplication.SliceRemoveDuplicates(url)

	go func() {
		for _, hostadd := range url {
			count += 1
			go ip(hostadd)
			if count >= 5 {
				for {
					if count <= 5 {
						break
					}
					time.Sleep(10 * time.Millisecond)
				}
			}
		}
	}()

	for {
		if int64(time.Since(start))/1000000000 >= src.Tm || count == 0 {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
