package src

func Program(host string, s data, f func(string2 string, int2 int)) {
	//s.Count = append(s.Count, 0)
	//s.Exit = append(s.Exit, false)
	f(host, s.Sum)
	s.Sum += 1
}
