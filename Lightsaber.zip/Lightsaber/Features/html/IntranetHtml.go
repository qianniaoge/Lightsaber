package html

import (
	"Lightsaber/src"
	"io/ioutil"
	"strconv"
	"strings"
)

//server:ip+":9200:"+user+":"+pass

func IntranetHtml() {
	defer src.HtmlWg.Done()
	for i, port := range src.PortName {
		src.IntranetMiddle = ""
		src.IntranetMiddle = strings.Replace(src.IntranetTitle, "COUNT", strconv.Itoa(i+1), -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "IPHOST", src.PortHost[i], -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "DATABASE", src.Database[port], -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "PORT", port, -1)
		src.IntranetHTML += src.IntranetMiddle
	}
	src.IntranetHtml = strings.Replace(src.IntranetHtml, "INTRANETTITLE", src.IntranetHTML, -1)
	src.IntranetHTML = ""
	for _, pass := range src.WeakPass {
		arr := strings.Split(pass, ":")
		src.IntranetMiddle = ""
		src.IntranetMiddle = strings.Replace(src.IntraneBody, "DATABASETYPE", arr[0], -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "IPHOST", arr[1], -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "URLNAME", arr[3], -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "HOSTURL", arr[4], -1)
		src.IntranetMiddle = strings.Replace(src.IntranetMiddle, "PORTURL", arr[2], -1)
		src.IntranetHTML += src.IntranetMiddle
	}
	src.IntranetHtml = strings.Replace(src.IntranetHtml, "INTRANETBODY", src.IntranetHTML, -1)

	data := []byte(src.IntranetHtml)
	err := ioutil.WriteFile(src.Name+".html", data, 0644)
	if err != nil {
		panic(err)
	}
}
