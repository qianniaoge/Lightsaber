package runner

import (
	"errors"
	"fmt"
	"os"

	"Lightsaber/Features/afrog/pkg/catalog"
	"Lightsaber/Features/afrog/pkg/config"
	"Lightsaber/Features/afrog/pkg/core"
	"Lightsaber/Features/afrog/pkg/fingerprint"
	"Lightsaber/Features/afrog/pkg/html"
	"Lightsaber/Features/afrog/pkg/log"
	"Lightsaber/Features/afrog/pkg/poc"
	http2 "Lightsaber/Features/afrog/pkg/protocols/http"
	"Lightsaber/Features/afrog/pkg/utils"
	"Lightsaber/Features/afrog/pocs"
)

type Runner struct {
	options *config.Options
	catalog *catalog.Catalog
}

func New(options *config.Options, htemplate *html.HtmlTemplate, acb config.ApiCallBack) error {
	runner := &Runner{options: options}

	// init callback
	options.ApiCallBack = acb

	// init config file
	config, err := config.New()
	if err != nil {
		return err
	}
	options.Config = config

	if len(options.Config.Reverse.Ceye.Domain) == 0 || len(options.Config.Reverse.Ceye.ApiKey) == 0 {
		homeDir, _ := os.UserHomeDir()
		return errors.New("please edit `api-key` and `domain` in `" + homeDir + "/.config/afrog/afrog-config.yaml`")
	}

	// init fasthttp
	http2.Init(options)

	// init targets
	if len(options.Target) > 0 {
		options.Targets.Set(options.Target)
	}
	if len(options.TargetsFilePath) > 0 {
		allTargets, err := utils.ReadFileLineByLine(options.TargetsFilePath)
		if err != nil {
			return err
		}
		for _, t := range allTargets {
			options.Targets.Set(t)
		}
	}
	if len(options.Targets) == 0 {
		return errors.New("could not find targets")
	}

	// init pocs
	allPocsEmbedYamlSlice := []string{}
	if len(options.PocsFilePath) > 0 {
		options.PocsDirectory.Set(options.PocsFilePath)
		// console print
		fmt.Println("   " + options.PocsFilePath)
	} else {
		// init default afrog-pocs
		if allDefaultPocsYamlSlice, err := pocs.GetPocs(); err == nil {
			allPocsEmbedYamlSlice = append(allPocsEmbedYamlSlice, allDefaultPocsYamlSlice...)
		}
		// init ~/afrog-pocs
		pocsDir, _ := poc.InitPocHomeDirectory()
		if len(pocsDir) > 0 {
			options.PocsDirectory.Set(pocsDir)
		}
	}
	allPocsYamlSlice := runner.catalog.GetPocsPath(options.PocsDirectory)

	if len(allPocsYamlSlice) == 0 && len(allPocsEmbedYamlSlice) == 0 {
		return errors.New("未找到可执行脚本(POC)，请检查`默认脚本`或指定新の脚本(POC)")
	}

	// init scan sum
	options.Count = len(options.Targets) * (len(allPocsYamlSlice) + len(allPocsEmbedYamlSlice))

	// fingerprint
	if !options.NoFinger {
		s, _ := fingerprint.New(options)
		s.Execute()
		if len(s.ResultSlice) > 0 {
			htemplate.AppendFinger(s.ResultSlice)
			printFingerResultConsole()
		}
	}

	//
	e := core.New(options)
	e.Execute(allPocsYamlSlice, allPocsEmbedYamlSlice)

	return nil
}

func printFingerResultConsole() {
	fmt.Printf("\r" + "[                   " + log.LogColor.Time("000 "+utils.GetNowDateTime()) + " " +
		log.LogColor.Vulner("Fingerprint") + "   " + log.LogColor.Info("INFO") + "                   ]" + "\r\n")
}
