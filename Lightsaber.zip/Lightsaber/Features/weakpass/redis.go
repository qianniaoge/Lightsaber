package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/garyburd/redigo/redis"
	"github.com/logrusorgru/aurora"
	"strconv"
	"time"
)

func linkredis(ip string, user string, pass string, redissum int) {
	conn, err := redis.Dial("tcp", "127.0.0.1:6379")
	if err == nil {

		Lock.Lock()
		sum := 0

		if len(ip+"-6379-"+user+"-"+pass) < 46 {
			sum = 46 - len(ip+"-6379-"+user+"-"+pass)
		} else if len(ip+"-21-"+user+"-"+pass) > 46 {
			sum = sum - 46
		}

		fmt.Printf("%-24s", "[ ")
		if len(ip+"-6379-"+user+"-"+pass) > 40 {
			fmt.Print(aurora.Red("redis"), " - ", aurora.Green(ip+"-6379-"+user+"-"+pass[:40]))
		} else {
			fmt.Print(aurora.Red("redis"), " - ", aurora.Green(ip+"-6379-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
		Lock.Unlock()

		src.WeakPass = append(src.WeakPass, "redis:"+ip+":6739:"+user+":"+pass)
		src.Redis.Exit[redissum] = true
	}
	defer conn.Close()
	src.Redis.Count[redissum] -= 1
}

func Redis(ip string, sum int) {
	defer src.WeakRunLock.Done()
	redisstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkredis(ip, user, pass, sum)
			src.Redis.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(redisstart))/1000000000 >= 5 || src.Redis.Count[sum] == 0 || src.Redis.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
