package src

import (
	"flag"
	"fmt"
	"github.com/logrusorgru/aurora"
)

func init() {

	fmt.Printf("%-36s", "[ ")
	fmt.Print(aurora.Bold(aurora.Red("Lightsber")))
	fmt.Printf("%37s\n", "]")

	fmt.Println(aurora.Bold(aurora.Red(Logo)))
	flag.BoolVar(&Op, "p", false, "output details")
	flag.StringVar(&Dr, "f", "", "specify open file or domain name")
	flag.Int64Var(&Tm, "time", 30, "Maximum execution time of individual modules Default 30s")
	flag.StringVar(&Name, "name", "Lightsaber", "output filename")
	flag.BoolVar(&At, "a", false, "Verify with POC")
	flag.StringVar(&Proxy, "proxy", "", "Specify the proxy host")
	flag.BoolVar(&Distributed, "link", false, "crawl link link link")
	flag.BoolVar(&Intranet, "intranet", false, "Detect all hosts on the intranet")
	flag.BoolVar(&Open, "open", false, "Open the file after execution")
	flag.BoolVar(&Web, "server", false, "Access result information using the web")
	flag.Parse()
}
