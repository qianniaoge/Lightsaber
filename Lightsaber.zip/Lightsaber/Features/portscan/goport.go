package portscan

import (
	"Lightsaber/Features/simplifyurl"
	"Lightsaber/src"
	"time"
)

func GoPortScan() {

	start := time.Now()

	for _, urlorip := range src.FileStorehouse {
		src.PortLock += 1
		go TcpGather(simplifyurl.SimplifyUrl(urlorip))

	}
	for {
		if int64(time.Since(start))/1000000000 >= src.Tm || src.PortLock == 0 {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
