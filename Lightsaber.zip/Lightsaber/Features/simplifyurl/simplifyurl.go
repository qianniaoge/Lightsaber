package simplifyurl

import "strings"

func SimplifyUrl(url string) string {
	if size := len(url); size > 8 {
		if strings.Count(url, "/") >= 3 {
			url = url[strings.Index(url, "/")+2:][:strings.Index(url[strings.Index(url, "/")+2:], "/")]
		} else if strings.Count(url, "/") == 1 {
			url = url[:strings.Index(url, "/")]
		}
		if strings.Count(url, "/") == 2 {
			url = url[strings.Index(url, "/")+2:]
		}
	}
	return url
}
