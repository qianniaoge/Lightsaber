package spider

import (
	"Lightsaber/Features/Deduplication"
	"Lightsaber/Features/proxy"

	//"Lightsaber/Features/proxy"
	"Lightsaber/Features/simplifyurl"
	"Lightsaber/src"
	"fmt"
	"github.com/gocolly/colly/v2"
	"github.com/logrusorgru/aurora"
	"github.com/schollz/progressbar/v3"
	"strconv"
	"strings"
	"time"
)

var (
	Bar *progressbar.ProgressBar
)

func Spider(url string) {

	if !src.Op {
		Bar = progressbar.NewOptions(-1,
			progressbar.OptionEnableColorCodes(true),
			progressbar.OptionSetWidth(24),
			progressbar.OptionSetDescription(" [[yellow]<--observe    \t [cyan][INFO][reset] 页面超链接爬取ing 请稍后 ······\t          \t ]"),
			progressbar.OptionSetTheme(progressbar.Theme{
				SaucerPadding: " ",
				BarStart:      "[",
				BarEnd:        "]",
			}),
			progressbar.OptionClearOnFinish(),
		)
	}

	src.UrlCopy = simplifyurl.SimplifyUrl(url)
	url = simplifyurl.SimplifyUrl(url)
	if strings.Contains(src.UrlCopy, "http") == false {
		src.UrlCopy = "http://" + src.UrlCopy
	} else if strings.Contains(src.UrlCopy, "https") {
		src.UrlCopy = strings.Replace(src.UrlCopy, "https", "http", -1)
	}

	var c *colly.Collector

	if src.Distributed {
		c = colly.NewCollector()
	} else {
		c = colly.NewCollector(
			colly.AllowedDomains(url),
		)
	}

	c.OnHTML("a[href]", func(e *colly.HTMLElement) {
		src.SpiderLock.Lock()
		s := e.Request.AbsoluteURL(e.Attr("href"))
		src.UrlHostName[s] = e.Text
		src.SpiderUrl = append(src.SpiderUrl, s)

		if src.Proxy != "" && strings.Contains(s, ".") {
			go proxy.Proxy(s)
		}
		if src.Op {

			sum := 68

			if len(s) < 57 {
				sum = 68 - len(s)
			} else if len(s) > 57 {
				sum = sum - 57
			}

			fmt.Printf("%-7s", "[ ")
			if len(s) > 57 {
				fmt.Print(aurora.Red("Link"), " - ", aurora.Yellow(s[:57]))
			} else {
				fmt.Print(aurora.Red("Link"), " - ", aurora.Yellow(s))
			}
			fmt.Printf("%"+strconv.Itoa(sum)+"s\n", "]")

		} else {
			Bar.Add(1)
		}
		src.SpiderLock.Unlock()
		if src.Distributed {
			err := c.Visit(e.Request.AbsoluteURL(e.Attr("href")))
			if err != nil {
				return
			}
		}
	})

	if err := c.Visit(src.UrlCopy); err != nil {
		return
	}
	src.SpideCount -= 1
}

func RunSpider(url []string) {
	start := time.Now()
	for _, ip := range url {
		src.SpideCount += 1
		go Spider(ip)
	}
	for {
		if int64(time.Since(start))/1000000000 >= src.Tm || src.SpideCount == 0 {
			if !src.Op {
				Bar.Reset()
				Bar.Finish()
			}
			fmt.Printf("%-32s", "[")
			fmt.Print(aurora.Red("～ 超链接爬取结束 ～").String())
			fmt.Printf("%30s\n", "]")
			Deduplication.SliceRemoveDuplicates(src.SpiderUrl)
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
