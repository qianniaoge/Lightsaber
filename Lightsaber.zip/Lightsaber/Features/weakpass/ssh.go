package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"golang.org/x/crypto/ssh"
	"strconv"
	"time"
)

func linkssh(ip string, user string, pass string, sshsum int) {
	_, err := ssh.Dial("tcp", ip+":"+"22", &ssh.ClientConfig{
		User:            user,
		Auth:            []ssh.AuthMethod{ssh.Password(pass)},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
	})
	if err == nil {
		Lock.Lock()
		sum := 0

		if len(ip+"-22-"+user+"-"+pass) < 48 {
			sum = 48 - len(ip+"-22-"+user+"-"+pass)
		} else if len(ip+"-22-"+user+"-"+pass) > 48 {
			sum = sum - 48
		}

		fmt.Printf("%-26s", "[ ")
		if len(ip+"-22-"+user+"-"+pass) > 40 {
			fmt.Print(aurora.Red("ssh"), " - ", aurora.Green(ip+"-22-"+user+"-"+pass[:40]))
		} else {
			fmt.Print(aurora.Red("ssh"), " - ", aurora.Green(ip+"-22-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
		Lock.Unlock()

		src.Ssh.Exit[sshsum] = true
		src.WeakPass = append(src.WeakPass, "ssh:"+ip+":22:"+user+":"+pass)
	}
	src.Ssh.Count[sshsum] -= 1
}

func Ssh(ip string, sum int) {
	defer src.WeakRunLock.Done()
	sshstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkssh(ip, user, pass, sum)
			src.Ssh.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(sshstart))/1000000000 >= 5 || src.Ssh.Count[sum] == 0 || src.Ssh.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
