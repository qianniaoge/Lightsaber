package src

import (
	"sync"
)

type data struct {
	Exit  [3000]bool
	Count [3000]int
	Sum   int
}

var (
	At       bool
	Op       bool
	Dr       string
	Tm       int64
	Name     string
	Sprid    = true
	Proxy    string
	Intranet bool
	Open     bool
	Web      bool
)

var (
	PrintLock   sync.Mutex
	UrlAddLock  sync.WaitGroup
	WeakRunLock sync.WaitGroup
	HtmlWg      sync.WaitGroup
	Addr        sync.Mutex
	SpiderLock  sync.Mutex
	ProxyWg     sync.Mutex
	PortLock    int
	HtmlBool    bool
)

var (
	PingCount      = 0
	FileStorehouse []string
	UrlAdd         = map[string]string{}
	UrlHostName    = map[string]string{}
	Subdomain      []string
	UrlDB          []string
	UserAgent      = map[int]string{
		1: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36",
		2: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:98.0) Gecko/20100101 Firefox/98.0",
		3: "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36",
	}
)

var (
	Port = []string{"20", "21", "22", "23", "137", "139", "80", "88", "443", "445", "1080", "3001", "5001", "8080", "888", "8888", "27017", "3306", "1433", "1521", "6379", "9200", "5432", "81", "82"}
	Pass = []string{"root", "tian", "123456", "Ztc123456", "mac", "<YourStrong@Passw0rd>", "HcZG4jsW6YVyyFN"}
)

var (
	PortHost []string
	PortName []string
)

var (
	Distributed bool
	UrlCopy     string
	SpiderUrl   []string
	SpideCount  = 0
)

var (
	WeakPass []string
)

var (
	Ssh     data
	Ftp     data
	Mysql   data
	Mssql   data
	Oracle  data
	Redis   data
	Smb     data
	Rdp     data
	Pg      data
	Mongo   data
	Elastic data
)

var (
	Database = map[string]string{
		"8080":  "www",
		"1080":  "socks",
		"80":    "http",
		"443":   "https",
		"20":    "ftp",
		"21":    "ftp",
		"22":    "ssh",
		"1521":  "oracle",
		"5432":  "postgresql",
		"3306":  "mysql",
		"6379":  "redis",
		"9200":  "elastic",
		"27017": "mongo",
		"1433":  "sqlserver",
		"445":   "smb",
		"3389":  "RDP",
	}
)
