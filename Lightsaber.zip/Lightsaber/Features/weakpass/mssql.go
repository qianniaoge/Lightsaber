package weakpass

import (
	"Lightsaber/src"
	"database/sql"
	"fmt"
	"github.com/logrusorgru/aurora"
	"strconv"
	"time"
)

func linkmssql(ip string, user string, pass string, mssqlsum int) {
	dataSourceName := fmt.Sprintf("server=%v;port=%v;user id=%v;password=%v;database=%v", ip, "1433", user, pass, "master")
	db, err := sql.Open("mssql", dataSourceName)
	if err == nil {
		defer db.Close()
		Lock.Lock()
		sum := 50

		if len(ip+"-1433-"+user+"-"+pass) < 47 {
			sum = 50 - len(ip+"-1433-"+user+"-"+pass)
		} else if len(ip+"-1433-"+user+"-"+pass) > 47 {
			sum = sum - 47
		}

		fmt.Printf("%-24s", "[ ")
		if len(ip+"-1433-"+user+"-"+pass) > 47 {
			fmt.Print(aurora.Red("mssql"), " - ", aurora.Green(ip+"-1433-"+user+"-"+pass[:47]))
		} else {
			fmt.Print(aurora.Red("mssql"), " - ", aurora.Green(ip+"-1433-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum)+"s\n", "]")
		Lock.Unlock()
		src.Mssql.Exit[mssqlsum] = true
		src.WeakPass = append(src.WeakPass, "mssql:"+ip+":1433:"+user+":"+pass)
	}
	src.Mssql.Count[mssqlsum] -= 1
}

func MsSql(ip string, sum int) {
	defer src.WeakRunLock.Done()
	mssqlstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkmssql(ip, user, pass, sum)
			src.Mssql.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(mssqlstart))/1000000000 >= 5 || src.Mssql.Count[sum] == 0 || src.Mssql.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
