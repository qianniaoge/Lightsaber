package runner

import (
	"Lightsaber/Features/afrog/pkg/config"
	"Lightsaber/Features/afrog/pkg/log"
	"Lightsaber/Features/afrog/pkg/utils"
)

func ShowBanner2(afrogLatestversion string) {
	old := ""
	if utils.Compare(afrogLatestversion, ">", config.Version) {
		old = log.LogColor.High(" (outdated)")
		old += log.LogColor.Title(" --> https://Lightsaber/Features/afrog/releases/tag/v" + afrogLatestversion)
	}
}
