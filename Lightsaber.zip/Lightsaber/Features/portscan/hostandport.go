package portscan

//
//func Split() {
//	for i := 1; i <= src.Count; i += 1 {
//		src.Str = append(src.Str, strings.Split(src.PortData[strconv.Itoa(i)], ":")...)
//	}
//	for i := 0; i < src.Count; i += 2 {
//		src.PortHost = append(src.PortHost, src.Str[i])
//		src.PortName = append(src.PortName, src.Str[i+1])
//	}
//}
