package weakpass

import (
	"Lightsaber/src"
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/logrusorgru/aurora"
	"strconv"
	"time"
)

func linkmysql(ip string, user string, pass string, sqlsum int) {

	db, err := sql.Open("mysql", user+":"+pass+"@tcp("+ip+":3306)/mysql?charset=utf8")
	if err == nil {
		if db.Ping() == nil {
			Lock.Lock()
			sum := 0

			if len(ip+"-3306-"+user+"-"+pass) < 46 {
				sum = 46 - len(ip+"-3306-"+user+"-"+pass)
			} else if len(ip+"-3306-"+user+"-"+pass) > 46 {
				sum = sum - 46
			}

			fmt.Printf("%-24s", "[ ")
			if len(ip+"-3306-"+user+"-"+pass) > 40 {
				fmt.Print(aurora.Red("mysql"), " - ", aurora.Green(ip+"-3306-"+user+"-"+pass[:40]))
			} else {
				fmt.Print(aurora.Red("mysql"), " - ", aurora.Green(ip+"-3306-"+user+"-"+pass))
			}
			fmt.Printf("%"+strconv.Itoa(sum+4)+"s\n", "]")
			Lock.Unlock()
			src.Mysql.Exit[sqlsum] = true
			src.WeakPass = append(src.WeakPass, "mysql:"+ip+":3306:"+user+":"+pass)
		}
	}
	defer db.Close()
	src.Mysql.Count[sqlsum] -= 1
}

func MySql(ip string, sum int) {
	defer src.WeakRunLock.Done()
	mysqlstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkmysql(ip, user, pass, sum)
			src.Mysql.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(mysqlstart))/1000000000 >= 5 || src.Mysql.Count[sum] == 0 || src.Mysql.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
