package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"gopkg.in/mgo.v2"
	"strconv"
	"time"
)

func linkmongo(ip string, user string, pass string, mongosum int) {
	session, err := mgo.Dial("mongodb://" + user + ":" + pass + "@" + ip + ":" + "27017" + "/" + "db")
	defer session.Close()
	if err == nil {
		Lock.Lock()
		sum := 0

		if len(ip+"-27017-"+user+"-"+pass) < 46 {
			sum = 46 - len(ip+"-27017-"+user+"-"+pass)
		} else if len(ip+"-27017-"+user+"-"+pass) > 46 {
			sum = sum - 46
		}

		fmt.Printf("%-24s", "[ ")
		if len(ip+"-27017-"+user+"-"+pass) > 40 {
			fmt.Print(aurora.Red("mongo"), " - ", aurora.Green(ip+"-27017-"+user+"-"+pass[:40]))
		} else {
			fmt.Print(aurora.Red("mongo"), " - ", aurora.Green(ip+"-27017-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
		Lock.Unlock()

		src.Mongo.Exit[mongosum] = true
		src.WeakPass = append(src.WeakPass, "mongo:"+ip+":27017:"+user+":"+pass)
	}
	src.Mongo.Count[mongosum] -= 1
}

func Mongon(ip string, sum int) {
	defer src.WeakRunLock.Done()
	mongostart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkmongo(ip, user, pass, sum)
			src.Mongo.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(mongostart))/1000000000 >= 5 || src.Mongo.Count[sum] == 0 || src.Mongo.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
