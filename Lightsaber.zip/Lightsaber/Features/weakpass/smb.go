package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"github.com/stacktitan/smb/smb"
	"strconv"
	"time"
)

func linksmb(ip string, user string, pass string, smbsum int) {
	options := smb.Options{
		Host:        ip,
		Port:        445,
		User:        user,
		Password:    pass,
		Domain:      "",
		Workstation: "",
	}
	session, err := smb.NewSession(options, false)
	if err == nil {
		session.Close()
		if session.IsAuthenticated {

			Lock.Lock()
			sum := 0

			if len(ip+"-445-"+user+"-"+pass) < 48 {
				sum = 48 - len(ip+"-445-"+user+"-"+pass)
			} else if len(ip+"-445-"+user+"-"+pass) > 48 {
				sum = sum - 48
			}

			fmt.Printf("%-24s", "[ ")
			if len(ip+"-445-"+user+"-"+pass) > 40 {
				fmt.Print(aurora.Red("smb"), " - ", aurora.Green(ip+"-445-"+user+"-"+pass[:40]))
			} else {
				fmt.Print(aurora.Red("smb"), " - ", aurora.Green(ip+"-445-"+user+"-"+pass))
			}
			fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
			Lock.Unlock()

			src.WeakPass = append(src.WeakPass, "smb:"+ip+":445:"+user+":"+pass)
			src.Smb.Exit[smbsum] = true
		}
	}
	src.Smb.Count[smbsum] -= 1
}

func Smb(ip string, sum int) {
	defer src.WeakRunLock.Done()
	smbstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linksmb(ip, user, pass, sum)
			src.Smb.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(smbstart))/1000000000 >= 5 || src.Smb.Count[sum] == 0 || src.Smb.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
