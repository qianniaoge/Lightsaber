package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"time"
)

func WeakRun() {

	fmt.Printf("%-32s", "[")
	fmt.Print(aurora.Red("～ 弱口令探测开始 ～").String())
	fmt.Printf("%30s\n", "]")

	for i, port := range src.PortName {
		if port == "21" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Ftp, Ftp)
		} else if port == "22" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Ssh, Ssh)
		} else if port == "1521" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Oracle, Oracle)
		} else if port == "3306" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Mysql, MySql)
		} else if port == "27017" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Mongo, Mongon)
		} else if port == "1433" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Mssql, MsSql)
		} else if port == "6379" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Redis, Redis)
		} else if port == "5432" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Pg, Pg)
		} else if port == "445" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Smb, Smb)
		} else if port == "3389" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Rdp, Rdp)
		} else if port == "9200" {
			src.WeakRunLock.Add(1)
			go src.Program(src.PortHost[i], src.Elastic, Elastic)
		}
	}
	src.WeakRunLock.Wait()
	time.Sleep(500 * time.Millisecond)
	fmt.Printf("%-35s", "[ ")
	fmt.Print(aurora.Red("弱口令探测结束"))
	fmt.Printf("%33s\n", "]")
}
