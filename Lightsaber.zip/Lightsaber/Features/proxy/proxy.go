package proxy

import (
	"Lightsaber/src"
	"io"
	"math/rand"
	"net/http"
	"net/url"
	"time"
)

func Proxy(u string) {

	uri, err := url.Parse(src.Proxy)

	if err != nil {
		src.Print("Proxy", "proxy error", true)
	}

	client := http.Client{
		Timeout: time.Second * 5,
		Transport: &http.Transport{
			Proxy: http.ProxyURL(uri),
		},
	}

	req, _ := http.NewRequest("GET", u, nil)
	src.ProxyWg.Lock()

	rand.Seed(time.Now().UnixNano())

	req.Header.Set("User-Agent", src.UserAgent[rand.Intn(2)])
	req.Header.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
	req.Header.Add("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8,ru;q=0.7")
	src.ProxyWg.Unlock()

	resp, err := client.Do(req)

	if err != nil {
		return
	}

	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {

		}
	}(resp.Body)

}
