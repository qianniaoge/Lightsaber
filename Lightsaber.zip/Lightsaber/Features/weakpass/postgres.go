package weakpass

import (
	"Lightsaber/src"
	"database/sql"
	"fmt"
	"github.com/logrusorgru/aurora"
	"strconv"
	"time"
)

func linkpg(ip string, user string, pass string, pgsum int) {
	dataSourceName := fmt.Sprintf("postgres://%v:%v@%v:%v/%v?sslmode=%v", user,
		pass, ip, "5432", "postgres", "disable")
	db, err := sql.Open("postgres", dataSourceName)
	if err == nil {
		if err := db.Ping(); err == nil {
			defer db.Close()

			Lock.Lock()
			sum := 0

			if len(ip+"-5432-"+user+"-"+pass) < 43 {
				sum = 43 - len(ip+"-5432-"+user+"-"+pass)
			} else if len(ip+"-5432-"+user+"-"+pass) > 43 {
				sum = sum - 43
			}

			fmt.Printf("%-24s", "[ ")
			if len(ip+"-5432-"+user+"-"+pass) > 40 {
				fmt.Print(aurora.Red("postgres"), " - ", aurora.Green(ip+"-5432-"+user+"-"+pass[:40]))
			} else {
				fmt.Print(aurora.Red("postgres"), " - ", aurora.Green(ip+"-5432-"+user+"-"+pass))
			}
			fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
			Lock.Unlock()

			src.Pg.Exit[pgsum] = true
			src.WeakPass = append(src.WeakPass, "postgres:"+ip+":5432:"+user+":"+pass)
		}
	}
	src.Pg.Count[pgsum] -= 1
}

func Pg(ip string, sum int) {
	defer src.WeakRunLock.Done()
	pgstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkpg(ip, user, pass, sum)
			src.Pg.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(pgstart))/1000000000 >= 5 || src.Pg.Count[sum] == 0 || src.Pg.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
