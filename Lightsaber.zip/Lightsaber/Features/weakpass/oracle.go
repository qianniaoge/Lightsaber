package weakpass

import (
	"Lightsaber/src"
	"database/sql"
	"fmt"
	"github.com/logrusorgru/aurora"
	"strconv"
	"time"
)

func linkoracle(ip string, user string, pass string, oraclesum int) {
	db, _ := sql.Open("godror", user+"/"+pass+"@"+ip+":"+"1521"+"/orcl")
	err := db.Ping()
	if err == nil {
		defer db.Close()
		Lock.Lock()
		sum := 0

		if len(ip+"-1521-"+user+"-"+pass) < 45 {
			sum = 45 - len(ip+"-1521-"+user+"-"+pass)
		} else if len(ip+"-1521-"+user+"-"+pass) > 45 {
			sum = sum - 45
		}

		fmt.Printf("%-24s", "[ ")
		if len(ip+"-1521-"+user+"-"+pass) > 40 {
			fmt.Print(aurora.Red("oracle"), " - ", aurora.Green(ip+"-1521-"+user+"-"+pass[:40]))
		} else {
			fmt.Print(aurora.Red("oracle"), " - ", aurora.Green(ip+"-1521-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
		Lock.Unlock()
		src.Oracle.Exit[oraclesum] = true
		src.WeakPass = append(src.WeakPass, "oracle:"+ip+":1521:"+user+":"+pass)
	}
	src.Oracle.Count[oraclesum] -= 1
}

func Oracle(ip string, sum int) {
	defer src.WeakRunLock.Done()
	oraclestart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkoracle(ip, user, pass, sum)
			src.Oracle.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(oraclestart))/1000000000 >= 5 || src.Oracle.Count[sum] == 0 || src.Oracle.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
