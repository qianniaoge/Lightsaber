package src

var (
	IntranetTitle = `<tr align="center">
        <td width="50px">COUNT</td>
        <td>IPHOST</td>
        <td width="200px">DATABASE</td>
        <td width="200px">PORT</td>
    </tr>`

	IntraneBody = `<tr>
        <td id="otd" align="center" style="border-bottom: solid;border-bottom-color: darkgray">DATABASETYPE</td>
		<td id="otd" align="center" style="border-bottom: solid;border-bottom-color: darkgray">IPHOST</td>
        <td id="otd" align="center" style="border-bottom: solid;border-bottom-color: darkgray">URLNAME</td>
        <td id="otd" align="center" style="border-bottom: solid;border-bottom-color: darkgray">HOSTURL</td>
		<td id="otd" align="center" style="border-bottom: solid;border-bottom-color: darkgray">PORTURL</td>
    </tr>`

	IntranetMiddle = ""

	IntranetHTML = ""
	IntranetHtml = `
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Lightsaber</title>

    <style type="text/css">
        h2.pos_abs {
            position: fixed;
            text-align: center;
        }
        a{
            text-decoration:none;
            font-weight: bold;
            font-size: 16px;
        }
        table{
            border-collapse:collapse;
        }
        #tab{
            table-layout:fixed;/* 只有定义了表格的布局算法为fixed，下面td的定义才能起作用。 */
        }
        #otd{
            width:100%;
            word-break:keep-all;/* 不换行 */
            white-space:nowrap;/* 不换行 */
            overflow:hidden;/* 内容超出宽度时隐藏超出部分的内容 */
            text-overflow:ellipsis;/* 当对象内文本溢出时显示省略标记(...) ；需与overflow:hidden;一起使用。*/
        }
    </style>

</head>

<body>

<h2 class="pos_abs" style="width: 100%;"><a href="Afrog" style="color: black;font-size: 25px">Lightsaber</a>
    <span style="color: coral;font-size: 15px">
        For TianTianYa
    </span>
</h2>

<table width="100%" border="0" align="center" >

    <tr style="height: 80px"></tr>

    <tr height="30px" align="center" style="font-weight: bold;color: aliceblue;font-size: 15px" bgcolor="black">
        <td width="80px">序号</td>
        <td>IP</td>
        <td width="300px">端口服务</td>
        <td width="200px">Port</td>
    </tr>

	INTRANETTITLE

</table>

<table width="100%" border="0" align="center" id="tab">
    <tr height="30px">
    </tr>
    <tr height="30px" align="center" style="font-weight: bold;color: aliceblue;font-size: 15px" bgcolor="black">
        <td>探测服务</td>
		<td>IP</td>
        <td>User</td>
        <td>Pass</td>
		<td>Port</td>
    </tr>
	
	INTRANETBODY
</table>

</body>
</html>
`
)
