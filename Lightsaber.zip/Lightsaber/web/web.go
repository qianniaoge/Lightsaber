package web

import (
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"html/template"
	"io/ioutil"
	"net/http"
	"strings"
)

func myWeb(w http.ResponseWriter, r *http.Request) {
	t, _ := template.ParseFiles(src.Name + ".html")
	err := t.Execute(w, "")
	if err != nil {
		return
	}
}

func Web() {

	data, _ := http.Get("https://httpbin.org/ip")
	body, _ := ioutil.ReadAll(data.Body)

	http.HandleFunc("/", myWeb)

	fmt.Printf("%-15s", "")
	fmt.Print(aurora.Red("服务已开启，访问地址 http://" + strings.Replace(string(body), "\n", "", -1)[14:strings.LastIndex(string(body), "}")-3] + ":8080 查看详细信息").String())
	if http.ListenAndServe(":8080", nil) != nil {
		fmt.Println("服务器开启错误: ")
	}
}
