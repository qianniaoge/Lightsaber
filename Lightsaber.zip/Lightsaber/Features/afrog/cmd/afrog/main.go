package afrog

import (
	"Lightsaber/Features/afrog/internal/runner"
	"Lightsaber/Features/afrog/pkg/config"
	"Lightsaber/Features/afrog/pkg/core"
	"Lightsaber/Features/afrog/pkg/html"
	"Lightsaber/Features/afrog/pkg/upgrade"
	"Lightsaber/Features/afrog/pkg/utils"
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"github.com/schollz/progressbar/v3"
	"sync"
)

var options = &config.Options{}
var htemplate = &html.HtmlTemplate{}
var lock sync.Mutex
var number = 0

func Afrog() {

	fmt.Println("[                                    ", aurora.Green("开启POC扫描"), "                               ]")
	afrogbar := progressbar.NewOptions(501*len(src.Subdomain),
		progressbar.OptionEnableColorCodes(true),
		progressbar.OptionSetPredictTime(false),
		progressbar.OptionSetWidth(59),
		progressbar.OptionSetDescription("[green][INFO][reset]POC扫描中"),
		progressbar.OptionSetTheme(progressbar.Theme{
			Saucer:        "[green]=[reset]",
			SaucerHead:    "[green]>[reset]",
			SaucerPadding: " ",
			BarStart:      "[",
			BarEnd:        "]",
		}),
		progressbar.OptionClearOnFinish(),
	)

	options.TargetsFilePath = src.Name + ".txt"

	Updrage := upgrade.New()
	Updrage.UpgradeAfrogPocs()
	if len(options.Output) == 0 {
		options.Output = src.Name + ".html"
	}
	htemplate.Filename = options.Output
	if err := htemplate.New(); err != nil {
		return
	}
	runner.New(options, htemplate, func(result interface{}) {
		lock.Lock()
		r := result.(*core.Result)
		if !options.Silent {
			options.CurrentCount++
			afrogbar.Add(1)
		}
		if r.IsVul {
			if r.FingerResult != nil {
			} else {
				number++
				htemplate.Result = r
				htemplate.Number = utils.GetNumberText(number)
				htemplate.Append()

				r.PrintColorResultInfoConsole(utils.GetNumberText(number))
			}
		}
		if !options.Silent {
			//fmt.Printf("\r%d/%d | %d%% ", options.CurrentCount, options.Count, options.CurrentCount*100/options.Count)
		}
		lock.Unlock()
	})
	afrogbar.Reset()
	afrogbar.Finish()
}
