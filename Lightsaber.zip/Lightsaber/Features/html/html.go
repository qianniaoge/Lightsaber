package html

import (
	"Lightsaber/src"
	"io/ioutil"
	"strconv"
	"strings"
)

func Html() {
	defer src.HtmlWg.Done()
	for count, url := range src.PortHost {
		src.Middle = strings.Replace(src.Title, "COUNT", strconv.Itoa(count+1), -1)
		src.Middle = strings.Replace(src.Middle, "URL", url, -1)
		src.Middle = strings.Replace(src.Middle, "IPAddr", src.UrlAdd[url], -1)

		if src.PortName[count] == "443" {
			src.Middle = strings.Replace(src.Middle, "HTTP", "s", -1)
		} else {
			src.Middle = strings.Replace(src.Middle, "HTTP", "", -1)
		}

		src.Middle = strings.Replace(src.Middle, "PORT", src.PortName[count], -1)
		src.HTML += src.Middle
	}
	src.Html = strings.Replace(src.Html, "TITLE", src.HTML, -1)

	src.HTML = ""
	sum := 0
	for url, name := range src.UrlHostName {
		src.Middle = strings.Replace(src.Body, "URLHOST", url, -1)
		src.Middle = strings.Replace(src.Middle, "URLNAME", name, -1)
		if sum < len(src.UrlDB) {
			if !strings.Contains(src.UrlDB[sum], "http") {
				src.Middle = strings.Replace(src.Middle, "HTTP", "http", -1)
			}
			src.Middle = strings.Replace(src.Middle, "HOSTURL", src.UrlDB[sum], -1)
		} else {
			src.Middle = strings.Replace(src.Middle, "HOSTURL", "", -1)
		}
		src.HTML += src.Middle
		sum += 1
	}

	src.Html = strings.Replace(src.Html, "BODY", src.HTML, -1)
	src.Html = strings.Replace(src.Html, "AFROG", "reports/"+src.Name+".html", -1)

	data := []byte(src.Html)
	err := ioutil.WriteFile(src.Name+".html", data, 0644)
	if err != nil {
		panic(err)
	}
}
