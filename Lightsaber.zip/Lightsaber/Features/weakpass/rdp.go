package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/icodeface/grdp"
	"github.com/icodeface/grdp/glog"
	"github.com/logrusorgru/aurora"
	"strconv"
	"time"
)

func linkrdp(ip string, user string, pass string, rdpsum int) {
	client := grdp.NewClient(ip+":"+"3389", glog.NONE)
	err := client.Login(user, pass)
	if err == nil {
		Lock.Lock()
		sum := 0

		if len(ip+"-1521-"+user+"-"+pass) < 48 {
			sum = 48 - len(ip+"-1521-"+user+"-"+pass)
		} else if len(ip+"-1521-"+user+"-"+pass) > 48 {
			sum = sum - 48
		}

		fmt.Printf("%-24s", "[ ")
		if len(ip+"-1521-"+user+"-"+pass) > 40 {
			fmt.Print(aurora.Red("rdp"), " - ", aurora.Green(ip+"-1521-"+user+"-"+pass[:40]))
		} else {
			fmt.Print(aurora.Red("rdp"), " - ", aurora.Green(ip+"-1521-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
		Lock.Unlock()

		src.Rdp.Exit[rdpsum] = true
		src.WeakPass = append(src.WeakPass, "RDP:"+ip+":3389:"+user+":"+pass)
	}
	src.Rdp.Count[rdpsum] -= 1
}

func Rdp(ip string, sum int) {
	defer src.WeakRunLock.Done()
	rdpstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkrdp(ip, user, pass, sum)
			src.Rdp.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(rdpstart))/1000000000 >= 5 || src.Rdp.Count[sum] == 0 || src.Rdp.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
