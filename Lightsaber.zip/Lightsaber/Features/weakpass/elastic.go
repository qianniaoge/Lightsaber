package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"gopkg.in/olivere/elastic.v3"
	"strconv"
	"time"
)

func linkelastic(ip string, user string, pass string, elasum int) {
	_, err := elastic.NewClient(elastic.SetURL(fmt.Sprintf("http://%v:%v", ip, "9200")))
	if err == nil {

		Lock.Lock()
		sum := 0

		if len(ip+"-9200-"+user+"-"+pass) < 44 {
			sum = 44 - len(ip+"-9200-"+user+"-"+pass)
		} else if len(ip+"-9200-"+user+"-"+pass) > 44 {
			sum = sum - 44
		}

		fmt.Printf("%-24s", "[ ")
		if len(ip+"-9200-"+user+"-"+pass) > 40 {
			fmt.Print(aurora.Red("elastic"), " - ", aurora.Green(ip+"-9200-"+user+"-"+pass[:40]))
		} else {
			fmt.Print(aurora.Red("elastic"), " - ", aurora.Green(ip+"-9200-"+user+"-"+pass))
		}
		fmt.Printf("%"+strconv.Itoa(sum+2)+"s\n", "]")
		Lock.Unlock()

		src.Elastic.Exit[elasum] = true
		src.WeakPass = append(src.WeakPass, "elastic:"+ip+":9200:"+user+":"+pass)
	}
	src.Elastic.Count[elasum] -= 1
}

func Elastic(ip string, sum int) {
	defer src.WeakRunLock.Done()
	elastart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkelastic(ip, user, pass, sum)
			src.Elastic.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(elastart))/1000000000 >= 5 || src.Elastic.Count[sum] == 0 || src.Elastic.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
