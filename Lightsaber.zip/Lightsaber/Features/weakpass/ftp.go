package weakpass

import (
	"Lightsaber/src"
	"fmt"
	"github.com/dutchcoders/goftp"
	"github.com/logrusorgru/aurora"
	"strconv"
	"sync"
	"time"
)

var Lock sync.Mutex

func linkftp(ip string, user string, pass string, ftpsum int) {
	ftp, err := goftp.Connect(ip + ":21")
	if err == nil {
		if err := ftp.Login(user, pass); err == nil {
			src.WeakPass = append(src.WeakPass, "ftp:"+ip+":21:"+user+":"+pass)

			Lock.Lock()
			sum := 52

			if len(ip+"-21-"+user+"-"+pass) < 47 {
				sum = 52 - len(ip+"-21-"+user+"-"+pass)
			} else if len(ip+"-21-"+user+"-"+pass) > 47 {
				sum = sum - 47
			}

			fmt.Printf("%-24s", "[ ")
			if len(ip+"-21-"+user+"-"+pass) > 47 {
				fmt.Print(aurora.Red("ftp"), " - ", aurora.Green(ip+"-21-"+user+"-"+pass[:47]))
			} else {
				fmt.Print(aurora.Red("ftp"), " - ", aurora.Green(ip+"-21-"+user+"-"+pass))
			}
			fmt.Printf("%"+strconv.Itoa(sum)+"s\n", "]")
			Lock.Unlock()
			src.Ftp.Exit[ftpsum] = true
		}
	}
	src.Ftp.Count[ftpsum] -= 1
}

func Ftp(ip string, sum int) {
	defer src.WeakRunLock.Done()
	ftpstart := time.Now()
	for _, user := range src.Pass {
		for _, pass := range src.Pass {
			go linkftp(ip, user, pass, sum)
			src.Ftp.Count[sum] += 1
		}
	}
	for {
		if int64(time.Since(ftpstart))/1000000000 >= 5 || src.Ftp.Count[sum] == 0 || src.Ftp.Exit[sum] {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
