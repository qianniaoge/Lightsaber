package ping

import (
	"Lightsaber/src"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"time"
)

func system_ping(ip string) {

	system_Type := runtime.GOOS
	cmd := exec.Command("ping", ip, "-c", "1", "-w", "3")
	if system_Type == "linux" || system_Type == "darwin" {
		cmd = exec.Command("ping", ip, "-c", "1", "-W", "3")
	}
	err := cmd.Run()
	if err != nil {
		src.PingCount -= 1
		return
	} else {
		src.Print("Ping", ip, true)
		src.FileStorehouse = append(src.FileStorehouse, ip)
		src.PingCount -= 1
	}
}

func Ping(ip string) {
	start := time.Now()
	if ip == "" {
		for _, s := range src.FileStorehouse {
			for c := 1; c <= 255; c++ {
				go system_ping(s[:strings.LastIndex(s, ".")+1] + strconv.Itoa(c))
				src.PingCount += 1
			}
		}
	} else {
		for c := 1; c <= 255; c++ {
			go system_ping(ip[:strings.LastIndex(ip, ".")+1] + strconv.Itoa(c))
			src.PingCount += 1
		}
	}

	for {
		if int64(time.Since(start))/1000000000 >= 10 || src.PingCount == 0 {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
}
