package filteravailablelinks

import (
	"Lightsaber/Features/Deduplication"
	"strings"
)

func Filteravailablelinks(links []string) []string {

	var link []string
	for _, url := range links {
		if !strings.Contains(url, " ") {
			link = append(link, url)
		}
	}

	link = Deduplication.SliceRemoveDuplicates(link)

	return link
}
