package src

var Title = `    <tr align="center">
        <td width="50px">COUNT</td>
        <td><a href="httpHTTP://URL:PORT">URL</a></td>
         <td width="200px">IPAddr</td>
        <td width="200px">PORT</td>
    </tr>`

var Middle = ""

var HTML = ""

var Body = `<tr>
        <td id="otd" style="border-bottom: solid;border-bottom-color: darkgray"><a href="URLHOST">&nbsp;&nbsp;&nbsp;&nbsp;URLHOST</a></td>
        <td id="otd" align="center"  style="border-bottom: solid;border-bottom-color: darkgray">&nbsp;&nbsp;URLNAME</td>
		<td id="otd" style="border-bottom: solid;border-bottom-color: darkgray"><a href="HTTP://HOSTURL" style="color: coral;">&nbsp;&nbsp;&nbsp;&nbsp;HOSTURL</a></td>
    </tr>`

var Html = `<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Lightsaber</title>

    <style type="text/css">
        h2.pos_abs {
            position: fixed;
            text-align: center;
        }
        a{
            text-decoration:none;
            color: coral;
            font-weight: bold;
            font-size: 16px;
        }
        table{
            border-collapse:collapse;
        }
        #tab{
            table-layout:fixed;/* 只有定义了表格的布局算法为fixed，下面td的定义才能起作用。 */
        }
        #otd{
            width:100%;
            word-break:keep-all;/* 不换行 */
            white-space:nowrap;/* 不换行 */
            overflow:hidden;/* 内容超出宽度时隐藏超出部分的内容 */
            text-overflow:ellipsis;/* 当对象内文本溢出时显示省略标记(...) ；需与overflow:hidden;一起使用。*/
        }
    </style>

</head>

<body>

<h2 class="pos_abs" style="width: 100%;"><a href="AFROG" style="color: black;font-size: 25px">Lightsaber</a>
    <span style="color: coral;font-size: 15px">
        For TianTianYa
    </span>
</h2>

<table width="100%" border="0" align="center" >

    <tr style="height: 70px"></tr>

    <tr height="30px" align="center" style="font-weight: bold;color: aliceblue;font-size: 15px" bgcolor="black">
        <td width="80px">序号</td>
        <td>URL</td>
        <td width="200px">IP地址</td>
        <td width="200px">Port</td>
    </tr>

    TITLE

</table>

<table width="100%" border="0" align="center" id="tab">
    <tr height="30px">
    </tr>
    <tr height="30px" align="center" style="font-weight: bold;color: aliceblue;font-size: 15px" bgcolor="black">
        <td>网址链接</td>
        <td>网址标题</td>
		<td>可能有用的URL</td>
    </tr>

    BODY
</table>

</body>
</html>
`
