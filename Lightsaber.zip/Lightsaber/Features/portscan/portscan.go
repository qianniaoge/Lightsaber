package portscan

import (
	"Lightsaber/src"
	"net"
	"time"
)

func TcpGather(ip string) {

	for _, port := range src.Port {
		address := net.JoinHostPort(ip, port)
		conn, err := net.DialTimeout("tcp", address, 125*time.Millisecond)
		if err == nil {
			if conn != nil {

				src.PortHost = append(src.PortHost, ip)
				src.PortName = append(src.PortName, port)

				src.Print("Port", ip+":"+port, true)
				_ = conn.Close()
			}
		}
	}
	src.PortLock -= 1
}
