package src

import (
	"fmt"
	"github.com/logrusorgru/aurora"
	"strconv"
)

func Print(name string, host string, i bool) {
	PrintLock.Lock()
	sum, num := 0, 0
	if i {
		sum, num = 30, 27
		if len(name) < 7 {
			num += 7 - len(name)
		}
		if len(name) > 7 {
			num -= len(name) - 7
		}
		if len(host) > 15 {
			sum -= len(host) - 15
		}
		if len(host) < 15 {
			sum += 15 - len(host)
		}
	} else {
		sum, num = 20, 41
		if len(name) < 7 {
			num += 7 - len(name)
		}
		if len(name) > 7 {
			num -= len(name) - 7
		}
		if len(host) > 15 {
			sum -= len(host) - 15
		}
		if len(host) < 15 {
			sum += 15 - len(host)
		}
	}
	fmt.Printf("%-"+strconv.Itoa(num)+"s", "[ ")
	fmt.Print(aurora.Red(name), " - ", aurora.Yellow(host))
	fmt.Printf("%"+strconv.Itoa(sum)+"s\n", "]")
	PrintLock.Unlock()
}
