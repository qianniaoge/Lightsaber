package file

import (
	"Lightsaber/Features/arp"
	"Lightsaber/Features/icmpscan/cmd/icmpscan"
	"Lightsaber/Features/ping"
	"Lightsaber/src"
	"bufio"
	"fmt"
	"github.com/logrusorgru/aurora"
	"os"
	"strings"
)

func Read(dir string) bool {
	file, err := os.Open(dir)
	if err != nil {
		if strings.Contains(dir, "http") || strings.Contains(dir, "www") || strings.Count(dir, ".") == 1 {
			src.FileStorehouse = append(src.FileStorehouse, src.Dr)
			src.HtmlBool = true
		} else if src.Intranet {
			src.HtmlBool = false
			icmpscan.IcmpScan()
			ping.Ping(dir)
			arp.ArpScan()
			src.Sprid = false
		} else if strings.Count(dir, ".") == 3 {
			src.HtmlBool = false
			src.FileStorehouse = append(src.FileStorehouse, src.Dr)
			src.Sprid = false
		} else {
			fmt.Printf("%-27s", "[")
			fmt.Print(aurora.Red("Error 未识别命令 请检查错误 ～").String())
			fmt.Printf("%25s\n", "]")
			src.Sprid = false
			return false
		}
		return true
	}
	src.HtmlBool = true
	fileScanner := bufio.NewScanner(file)
	for fileScanner.Scan() {
		src.FileStorehouse = append(src.FileStorehouse, fileScanner.Text())
	}
	if err := fileScanner.Err(); err != nil {
		src.Print("file", "Error while reading file", true)
	}
	file.Close()
	return true
}
