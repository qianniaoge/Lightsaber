package cmd

import (
	"Lightsaber/Features/afrog/cmd/afrog"
	"Lightsaber/Features/file"
	"Lightsaber/Features/filteravailablelinks"
	"Lightsaber/Features/hostAdd"
	"Lightsaber/Features/html"
	"Lightsaber/Features/portscan"
	"Lightsaber/Features/spider"
	"Lightsaber/Features/weakpass"
	"Lightsaber/src"
	"Lightsaber/web"
	"fmt"
	"github.com/logrusorgru/aurora"
	"os/exec"
	"runtime"
	"strconv"
	"time"
)

func Cmd() {
	fmt.Println("[                               ", aurora.Green("Lightsaber探测开始"), "                             ]")
	start := time.Now()
	if !file.Read(src.Dr) {
		return
	}
	portscan.GoPortScan()
	if src.Sprid {
		src.UrlAddLock.Add(1)
		go hostAdd.GoAddHost(src.PortHost)
		spider.RunSpider(src.FileStorehouse)
		src.Subdomain = filteravailablelinks.Filteravailablelinks(src.SpiderUrl)
		file.Write(src.Subdomain)
	} else {
		weakpass.WeakRun()
	}
	src.HtmlWg.Add(1)
	if src.HtmlBool {
		go html.Html()
	} else {
		go html.IntranetHtml()
	}

	src.UrlAddLock.Wait()
	src.HtmlWg.Wait()

	if src.Open {

		system_Type := runtime.GOOS
		var cmd *exec.Cmd

		if system_Type == "darwin" {
			cmd = exec.Command("open", src.Name+".html")
		} else if system_Type == "linux" {
			cmd = exec.Command("firefox", src.Name+".html")
		} else if system_Type == "windows" {
			cmd = exec.Command("start", src.Name+".html")
		}
		err := cmd.Run()
		if err != nil {
			src.PingCount -= 1
			return
		}

	}

	if src.Web {
		go func() {
			if src.At {
				afrog.Afrog()
			}
		}()
		web.Web()
	}

	if src.At {
		afrog.Afrog()
	}

	src.Print("    运行时间:", strconv.FormatInt(int64(time.Since(start)/1000000000), 10)+"s", false)
}
