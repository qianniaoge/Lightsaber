package icmpscan

import (
	"Lightsaber/Features/icmpscan"
	"Lightsaber/src"
	"fmt"
	"github.com/logrusorgru/aurora"
	"os"
	"strconv"
	"time"
)

func IcmpScan() {
	c := struct {
		Interface string
		Networks  []string
		Timeout   time.Duration
		DNSServer string
	}{
		Interface: "",
		Networks:  nil,
		Timeout:   1000 * time.Millisecond,
		DNSServer: "",
	}

	useUDP := os.Getuid() != 0

	hosts, err := icmpscan.Run(icmpscan.Spec{
		Interface: c.Interface,
		Networks:  c.Networks,
		Timeout:   c.Timeout,
		UseUDP:    useUDP,
		Hostnames: true,
		MACs:      true,
		DNSServer: c.DNSServer,
	})
	if err != nil {
		return
	}

	for i, host := range hosts {
		if host.Active {
			if host.MAC == "" {
				host.MAC = "-"
			}
			if host.Hostname == "" {
				host.Hostname = "-"
			}

			sum := 52

			if len(strconv.Itoa(i+1)+fmt.Sprintf("%v", host.IP)+host.MAC+host.Hostname) < 52 {
				sum = 52 - len(strconv.Itoa(i+1)+fmt.Sprintf("%v", host.IP)+host.MAC+host.Hostname)
			} else if len(strconv.Itoa(i+1)+fmt.Sprintf("%v", host.IP)+host.MAC+host.Hostname) > 52 {
				sum = sum - 52
			}

			fmt.Printf("%-20s", "[ ")
			fmt.Print(aurora.Red("Icmp - "))
			fmt.Print(aurora.Yellow(host.IP))
			fmt.Print(aurora.Yellow(" - " + host.MAC + " - " + host.Hostname))
			fmt.Printf("%"+strconv.Itoa(sum-2)+"s\n", "]")
			src.FileStorehouse = append(src.FileStorehouse, fmt.Sprintf("%v", host.IP))
		}
	}
}
