package main

import (
	"Lightsaber/Features/afrog/internal/runner"
	"Lightsaber/Features/afrog/pkg/config"
	"Lightsaber/Features/afrog/pkg/core"
	"Lightsaber/Features/afrog/pkg/html"
	"fmt"
)

func main() {

	options := config.Options{
		Target:          "http://127.0.0.1", // 指定扫描的URL/Host
		TargetsFilePath: "",                 // 指定需要扫描的URL/Host文件（一行一个）
		PocsFilePath:    "./afrog-pocs",     // 指定需要扫描的POC脚本的路径（非必须，默认加载{home}/afrog-pocs）
		Output:          "./result.html",    // 输出扫描报告，比如：-o result.html
	}

	htemplate := &html.HtmlTemplate{}
	htemplate.Filename = options.Output
	if err := htemplate.New(); err != nil {
		return
	}
	runner.New(&options, htemplate, func(result interface{}) {
		r := result.(*core.Result) // result 结构体里有你要的任何数据^^

		options.OptLock.Lock()
		defer options.OptLock.Unlock()

		options.CurrentCount++ // 扫描进度计数器（当前扫描数）

		if r.IsVul {
			r.PrintColorResultInfoConsole(htemplate.Number) // 如果存在漏洞，打印结果到 console

			if len(r.Output) > 0 {
				htemplate.Result = r
				htemplate.Append()
			}
		}

		// 扫描进度实时显示
		fmt.Printf("\r%s%d/%d | %d%% ", "[%-30s", options.CurrentCount, options.Count, options.CurrentCount*100/options.Count)
	})
}
