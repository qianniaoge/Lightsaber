package main

import (
	"Lightsaber/cmd"
)

func main() {
	cmd.Cmd()
}
