package file

import (
	"Lightsaber/Features/Deduplication"
	"Lightsaber/Features/simplifyurl"
	"Lightsaber/src"
	"io/ioutil"
	"strings"
)

func Write(filewrite []string) {

	for i, data := range filewrite {
		for _, url := range filewrite[i+1:] {
			if !strings.Contains(url, simplifyurl.SimplifyUrl(data)) && !strings.Contains(url+data, "javascript") && strings.Contains(url+data, ".") {
				src.UrlDB = append(src.UrlDB, simplifyurl.SimplifyUrl(data))
			}
		}
	}

	src.UrlDB = Deduplication.SliceRemoveDuplicates(src.UrlDB)
	filedata := ""

	for _, data := range src.UrlDB {
		filedata += data + "\n"
	}

	file := []byte(filedata)
	err := ioutil.WriteFile(src.Name+".txt", file, 0644)
	if err != nil {
		panic(err)
	}
}
